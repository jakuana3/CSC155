/************************************************************************
* Name: Your name                                                 CSC 155
* Date: Today's date                                              Lab 6   
*************************************************************************
* Statement: Displays headings for a payroll report.
* Specifications:
* Input  - none
* Output - Payroll report headings
************************************************************************/

//header files I/O, formatting, strings
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
using namespace std;

// function prototypes
// instructions()- describes the program usage to the user
void instructions();

// reportTitle() displays the payroll report titles in columnar format
void reportTitle();

// displayEmployeeInfo() displays the information for each employee
void displayEmployeeInfo(string& , double, double, 
                         double, double, double);

// totalAmounts() displays the total gross and net amounts
void totalAmounts(double, double);

// readData() inputs values from the file for processing
void readData(ifstream&, string&, double&, double&, double&);

// calculate() determines gross and net income and updates totals
void calculate(double, double, double, double, double&, double&);

int main()
{

  string employee;
  double hourly, hours, taxrate, gross, net, totalgross = 0.0, totalnet = 0.0;

  ifstream fin("payroll.txt");

	// call the function instructions
	instructions();

	// call the function reportTitle
	reportTitle();

        // read data for each employee
        readData(fin, employee, hourly, hours, taxrate);
	// input loop
	while(!fin.eof())
	  {

	    // determine values for gross
	    if (hours > 40.0)
		gross = 40.0* hourly + 1.5*(hours - 40.0)*hourly;
	    else 
	        gross = hours * hourly;
	    totalgross += gross;

	    // determine values for net
	    net = (1.0 - taxrate/100.0)*gross;
	    totalnet += net;

	    // display info for this employee
	    displayEmployeeInfo(employee, hourly, hours, taxrate, gross, net);

            // read data for each employee
            readData(fin, employee, hourly, hours, taxrate);
	  }

	// display totals
	totalAmounts(totalgross, totalnet);

	return 0;
}

// instructions() describes the program usage to the user
void instructions()
{
	// display program instructions 
	cout << "This payroll program calculates an individual "
		 << "employee pay and\ncompany totals "
		 << "using data from a data file payroll.txt.\n" 
		 << "\n\nA payroll report showing payroll information "
		 << " is displayed.\n\n";
}


// reportTitle() displays the payroll report titles in columnar format
void reportTitle()
{
	// set program formatting
	cout << setprecision(2) << fixed << showpoint << left;

	// display report titles
	cout << setw(7)  << "Emp." 
             << setw(20) << "Employee" << setw(10) << "Hourly" 
             << setw(10) << "Hours" << setw(10) << "Tax" << setw(10) 
             << "Gross" << setw(10) << "Net" << endl;

	cout << setw(7)  << "Numb."
             << setw(20) << "Name" << setw(10) << "Rate" 
             << setw(10) << "Worked" << setw(10) << "Rate" << setw(10) 
             << "Amount" << setw(10) <<"Amount" << endl << endl;
}

void displayEmployeeInfo(string& name, double hourly, double hours, 
                         double taxrate, double gross, double net)
{

  int static count = 1;

  cout << left << setw(7) << count << setw(20) << name 
       << setw(6) << setprecision(2) 
       << fixed << right << showpoint << hourly << setw(10) << hours 
       << setw(8) << taxrate << setw(12) << gross << setw(10) << net << endl;
  count++;
}

void totalAmounts(double tgross, double tnet)
{
  cout << "Totals" << setprecision(2) << fixed << showpoint << right 
       << setw(8) << tgross << setw(8) << tnet << endl;
}

// readData() inputs values from the file for processing
void readData(ifstream& fin, string& name, double& hourly, double& hours, double& taxrate)
{
 // read data for each employee
    getline(fin, name, '#');
    fin >> hourly >> hours >> taxrate;
    fin.ignore(100, '\n');
}
