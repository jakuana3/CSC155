/************************************************************************
* Name: Your name                                                 CSC 155
* Date: Today's date                                              Lab 2   
*************************************************************************
* Statement: Determine type of flooring for a new home
* Specifications:
* Input  - Flooring selector
* Output - Appropriate output message based upon selector value
************************************************************************/

// Header files for I/O and string
#include <iostream>
#include <string>
using namespace std;

// declaration of main program
int main()
{

  // objects used to store data
  char selector;
  string con_string = "Scored concrete for $3000",
    car_string = "Carpeting for $5000",
    wood_string = "Wood floors in the living area, carpeting in the bedrooms,"
    "\n\tand tile in the bath areas for $10,000",
    out_string = "\nYou chose Option ";
  
  // 0. display a statement describing the program
  
  cout << "This program asks that user to enter a choice of flooring for a new home\n\n\n" 
       << "Enter the number that matches your flooring choice:\n"
       << "Option 1: " << con_string
       << "\nOption 2: " << car_string
       << "\nOption 3: " << wood_string << "\n\n";
  
  // 1. input the selector char
  
  cin >> selector;
  
  // 2. determine the appropriate output string and
  // 3. display the results
  
  if (selector == '1')
    cout << out_string << selector << ": " << con_string << endl;
  else if (selector == '2')
    cout << out_string << selector << ": " << car_string << endl;
  else if (selector == '3')
    cout << out_string << selector << ": " << wood_string << endl;
  else
    cout <<  "\nYour selection is not available\n";
  
} // end of the main
