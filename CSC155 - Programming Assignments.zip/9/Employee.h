/* solution to 1c on page 380 of the C++ Lab Manual by Scholl
 */


#include <string>
#include "Date.h"
using namespace std;

class Employee {

 public:
  Employee(double);
  Employee();
  void pay();
  void eeo();

 private:
  string lastName;
  string firstName;
  char ethnicity;
  double rateOfPay;
  Date startDate;
  void newHire();
};
