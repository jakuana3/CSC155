// Enter your name as a comment for program identification
// Program assignment testEmployee3.cpp
// Enter your class section, and time

/* The program testEmployee3.cpp tests the class Employee.
   The class Date is included so 
   that the Employee class can use the Date data type. */ 
/* Data is entered to create an employee data file. */
/* A payroll report and equal employment opportunity report 
   showing ethnicity data is displayed. */

//header files
/* use the correct preprocessor directives for 
   input/output */
#include "Employee.h"
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;


/* The function instruct describes the use 
   and purpose of the program. */
void instruct();

// main function
int main()
{
	// declare variables
	/* an Employee object hourly to test the
	   default constructor and an Employee
	   object suit to test the constructor
	   with a parameter */

	instruct();

	Employee hourly[5];
	Employee suit(25);
	
	for (int loop = 0; loop < 5; loop++)
	{
		// call the member function pay with the object hourly
		hourly[loop].pay();
		// call the member function eeo with the object hourly
		hourly[loop].eeo();
	}
	// call the member function pay with the object suit
	suit.pay();
	// call the member function eeo with the object suit
	suit.eeo();

	return 0;
}

void instruct()
{
	cout << "The program testEmployee.cpp is a driver program to "
		    "test the class Employee.\n\n";
}

/*
The program testEmployee.cpp is a driver program to test the class Employee.

Enter first name and last name separated by a space: Angela Vito
Please enter starting date mm dd yyyy for Angela Vito: 01 14 2002
Please enter your ethnicity: (C)aucasian, (A)frican American,
(N)ative American, (H)ispanic, A(s)ian, (O)ther: C

Enter first name and last name separated by a space: Boubacar Zimba
Please enter starting date mm dd yyyy for Boubacar Zimba: 3 5 2003
Please enter your ethnicity: (C)aucasian, (A)frican American,
(N)ative American, (H)ispanic, A(s)ian, (O)ther: A

Enter first name and last name separated by a space: Charles Casey
Please enter starting date mm dd yyyy for Charles Casey: 5 8 2001
Please enter your ethnicity: (C)aucasian, (A)frican American,
(N)ative American, (H)ispanic, A(s)ian, (O)ther: C

Enter first name and last name separated by a space: Wanda Torres
Please enter starting date mm dd yyyy for Wanda Torres: 12 14 2000
Please enter your ethnicity: (C)aucasian, (A)frican American,
(N)ative American, (H)ispanic, A(s)ian, (O)ther: H

Enter first name and last name separated by a space: Huy Wuan
Please enter starting date mm dd yyyy for Huy Wuan: 3 22 1999
Please enter your ethnicity: (C)aucasian, (A)frican American,
(N)ative American, (H)ispanic, A(s)ian, (O)ther: s

Enter first name and last name separated by a space: Jack Smith
Please enter starting date mm dd yyyy for Jack Smith: 8 12 1998
Please enter your ethnicity: (C)aucasian, (A)frican American,
(N)ative American, (H)ispanic, A(s)ian, (O)ther: o

How many hours did Angela Vito work this week? 37

Weekly pay for Angela Vito is $268.25
The employee ethnicity is Caucasian.

How many hours did Boubacar Zimba work this week? 42

Weekly pay for Boubacar Zimba is $311.75
The employee ethnicity is African American.

How many hours did Charles Casey work this week? 14

Weekly pay for Charles Casey is $101.50
The employee ethnicity is Caucasian.

How many hours did Wanda Torres work this week? 47

Weekly pay for Wanda Torres is $366.13
The employee ethnicity is Hispanic.

How many hours did Huy Wuan work this week? 28

Weekly pay for Huy Wuan is $203.00
The employee ethnicity is Asian.

How many hours did Jack Smith work this week? 56

Weekly pay for Jack Smith is $1600.00
The employee ethnicity is not listed.
*/
