/* solution to 1c on page 380 of the C++ Lab Manual by Scholl
 */

#include "Employee.h"
#include <iostream>
#include <iomanip>
using namespace std;

Employee::Employee(double rate)
{
  rateOfPay = rate;
  newHire();
}

Employee::Employee()
{
  rateOfPay = 7.25;
  newHire();
}

void Employee::newHire()
{
  cout << "Enter the first name and last name spearated by a space: ";
  cin >> firstName >> lastName;
  cin.ignore();

  cout << "\nPlease enter the starting date mm dd yyyy for " 
       << firstName << ' ' << lastName << ": ";
  startDate.getData();

  cout << "\nPleae enter your ethnicity: (C)aucasian, (A)frican American,\n"
       << "(N)ative American, (H)ispanic, A(s)ian, (O)ther: ";
  cin >> ethnicity;
  cin.ignore();
  ethnicity = toupper(ethnicity);
  cout << endl;
}

void Employee::pay()
{
  double hours, payout;

  cout << "How many hours did " << firstName << ' ' << lastName
       << " work this week? ";
  cin >> hours;

  payout = (hours > 40)?rateOfPay*40 +1.5*(hours-40)*rateOfPay:hours*rateOfPay;
  cout << "\nWeekly pay for " << firstName << ' ' << lastName << " is $"
       << setprecision(2) << fixed << showpoint << payout << endl;
}

void Employee::eeo()
{

  cout << "The employee ethnicity is ";
  switch(ethnicity)
    {
    case 'C': cout << "Caucasian.\n\n";
      break;
    case 'A': cout << "African American.\n\n";
      break;
    case 'N': cout << "Native American.\n\n";
      break;
    case 'H': cout << "Hispanic.\n\n";
      break;
    case 'S': cout << "Asian.\n\n";
      break;
    case 'O': cout << "not listed.\n\n";
      break;
    }
}
