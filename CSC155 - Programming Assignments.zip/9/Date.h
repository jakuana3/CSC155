/* Class declaration for a Date object.
   This is a solution to exercise 1c on page 375 of the C++ Lab Manual
   by Scholl. */ 

/* Date.h and Date.cpp are to be used to support lab 9 which is a solution 
   to 3b on page 381 of the C++ Lab Manual by Scholl */

class Date
{

public:
  void getData();          // support for input from the keyboard
  void displayDate();      // support for output to the monitor
  bool good;               // boolean used to ensure validity of input

private:
  void checkFormat(int &); // ensure that input data is int or space
  void validate();         // verify month, date and year make sense
  int month, day, year;    // values set by getDate()

};
