/************************************************************************
* Name: Your name                                                 CSC 155
* Date: Today's date                                              Lab 9   
*************************************************************************
* Statement: Determine employee information to determine payroll
* Specifications:
* Input  - Employee name, starting date, ethnicity, hours worked
* Output - Employee name, weekly pay, ethnicity
************************************************************************/

/* copy the contents of this program to the file Employee3.cpp to create
   a solution to problem 3 on page 381 of the C++ Lab Manual by Scholl
*/

//header files
#include "Employee.h"
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main()
{
	cout << "The program testEmployee.cpp is a driver program to "
	     << "test the class Employee.\n\n";
	
	// declare variables
	Employee hourly;
	Employee suit(25);

	// call the member function pay with the object hourly
	hourly.pay();
	// call the member function eeo with the object hourly
	hourly.eeo();

	// call the member function pay with the object suit
	suit.pay();
	// call the member function eeo with the object suit
	suit.eeo();
	
}
