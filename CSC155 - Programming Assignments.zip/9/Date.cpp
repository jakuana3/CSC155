/* Class declaration for a Date object.
   This is a solution to exercise 1c on page 375 of the C++ Lab Manual
   by Scholl. 
*/ 

/* Date.h and Date.cpp are to be used to support lab 9 which is a solution 
   to 3b on page 381 of the C++ Lab Manual by Scholl 
*/

#include <iostream>
#include "Date.h"
using namespace std;

/* the member function getData enters a date in the format mm dd yyyy,
   checks to see that integer data is entered, and validates the date
*/
void Date::getData()
{
	// call the function checkFormat with the parameter month
	checkFormat(month);
	// if month is valid, verify the day
	if (good)
		checkFormat(day);
	// if day is valid, verify the year
	if (good)
		checkFormat(year);
	// if year is valid, validate
	if (good)	
		validate();
}

/* the member function checkFormat checks to see that data entered is 
   numeric and if it is enters the data into a reference numeric variable,
   and sets a Boolean value to true if numeric data is entered and false 
   if it is not
*/
void Date::checkFormat(int &temp)
{
	// declare variables
	// a character variable ch to peek at the data entered
	char ch;

	// assign the data member good to false
	good = false;
	// assign to ch the next value in the buffer
	ch=cin.peek();
	/* if the next value is an integer, enter the value into the 
           reference variable in the parameter list and assign the data 
           member good to true
        */
	if (ch >= '0' && ch <= '9' || ch == ' ')
	{
		cin >> temp;
		good = true;
	}
	/* if the next value is not an integer display a message that the 
           wrong date format was used 
        */
	else
	{
		cout << "You used the wrong format to enter the date.\n";
		cin.ignore(100, '\n');
	}
}

/* the member function validate checks to see that the month entered is 
   valid, the number of days entered is valid depending on the month entered 
*/
void Date::validate()
{
	// declare variables
	// an integer array with the number of days in each month
	int calendar[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

	// assign the data member good to false
	good = false;
	/* test to see that month is between 1 and 12, if month is valid, 
           test to see that the number of days entered is valid, and if 
           valid assign the data member good to true 
        */
	if (month >= 1 && month <= 12)
		if (day >= 1 && day <= calendar[month-1])
			good = true;
	// if and invalid date is entered, display a message
	if (!good)
		cout << "You entered an invalid date\n";
}
	
/* the member function displayDate displays the date entered 
*/	
void Date::displayDate()
{
	cout << "You entered: " << month << '-' << day << '-' << year << endl;

}

