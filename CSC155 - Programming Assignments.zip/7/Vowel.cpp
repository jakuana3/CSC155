/************************************************************************
* Name: Your name                                                 CSC 156
* Date: Today's date                                              Lab 7   
*************************************************************************
* Statement: Count the number of occurrences of vowels in an input string
* Specifications:
* Input  - search string
* Output - the string and the count of each vowel
************************************************************************/

// header files for I/O and strings
#include <iostream>
#include <string>
using namespace std;


// declaration of main program
int main()
{

   // objects used to store data
   string search_string;  // input string to search for vowels
   char newlch;           // newline character to flush input

   int a_count = 0,      // count of the number of a occurrenes 
   e_count = 0,      // count of the number of e occurrenes 
   i_count = 0,      // count of the number of i occurrenes 
   o_count = 0,      // count of the number of o occurrenes 
   u_count = 0,      // count of the number of u occurrenes 
   y_count = 0;      // count of the number of y occurrenes 

  // display an informational message and prompt for input
   cout << "This program asks the user for a sentence,\n"
        << "searches the sentence for all vowels,\n"
        << "and displays the number of times each vowel appears in the sentence.\n\n";

  // input the search string
   cout << "\n\nEnter the sentence to search:\n";
   getline(cin, search_string);

  // determine the vowel count character count
   for (int i=0; i < search_string.length(); i++)
     switch (tolower(search_string[i]))
       {
       case 'a':a_count++;
	 break;
       case 'e':e_count++;
	 break;
       case 'i':i_count++;
	 break;
       case 'o':o_count++;
	 break;
       case 'u':u_count++;
	 break;
       case 'y':if ((i+1 == search_string.length()) ||
                    (!isalpha(search_string[i+1])))
                    y_count++;
       }


  // display the results
   cout << "\n\nThe sentence has " << search_string.length() << " characters.\n\n"
	<< "There are " << a_count << " a\'s, "
	<< e_count << " e\'s, "
	<< i_count << " i\'s, "
	<< o_count << " o\'s, and "
	<< u_count << " u\'s.\n";
// 	<< y_count << " y\'s.\n";

} // end of main

