/************************************************************************
* Name: Your name                                                 CSC 155
* Date: Today's date                                              Lab 4   
*************************************************************************
* Statement: Display a multiples of integers in a tabular format
* Specifications:
* Input  - None
* Output - Columns labled with letters A-E and rows labled with numbers
*************************************************************************/
#include <iostream>
#include <iomanip>
using namespace std;

int main()

{
   cout << setw(5) << ' ';
   for (char x = 'A'; x <= 'E'; x++)
      cout << setw(5) << x;
   cout << endl;

   for (int r = 1; r <= 5; r++)
   {
      cout << setw(5) << r;
      for (int c = 1; c <= 5; c++)
      {
         cout << setw(5) << r*c;
      }
     cout << endl;
   }
}
