/************************************************************************
* Name: Your name                                                 CSC 155
* Date: Today's date                                              Lab 0   
*************************************************************************
* Statement: Determine owner, selling cost and commission for house sale
* Specifications:
* Input  - owner
*        - selling cost
* Output - owner
*        - selling cost
*        - commission
************************************************************************/

// header files for I/O and string objects
#include <iostream>
#include <string>
using namespace std;

// declaration of main program
int main()
{

// objects used to store data
	string seller;  // seller's name
	double price,   // price of the house
	    cost,       // the cost to sell the home
	    commission; // commision on the sale of the listing and selling agents

	// output descriptive messages
	cout << "This program calculates the cost to sell a home\n" 
             << "and the commission paid to an individual sales agent.\n\n";

	cout << "The user is asked for the last name of the seller and the\n" 
             << "sales price.\n\n";

        // prompt the user for input values
	cout << "Please enter the owner's last name: ";
        cin >> seller;
        cout << "\nPlease enter the sales price of the home: ";
        cin >> price;

	// calculate the cost and the commission
	cost = 0.06 * price;
        commission = 0.015 * price;

	// display the results
	cout << "\nThe " << seller << "'s home sold for $" << price << endl;
	cout << "The cost to sell the home was $" << cost << endl;
	cout << "The selling and listing agent earned $" << commission << endl;

} // end of main

