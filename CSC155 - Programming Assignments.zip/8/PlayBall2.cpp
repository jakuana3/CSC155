/************************************************************************
* Name: Your name                                                 CSC 155
* Date: Today's date                                              MP 8   
*************************************************************************
* Statement: Determine hits, walks and outs for players on a baseball team
* Specifications: 
* Input  - Number of games
*        - for each game, there are nine players
*        -     for each player, input and update
*        -         Player number, hist, walks, outs
* Output - team with updated sums
************************************************************************/

// header files I/O
#include <iostream>
using namespace std;

// declaration of the main
int main()
{
  const int TEAMSIZE = 30;

// objects used to store data

    int number,    // number, hits, walks, outs
          hits,
          walks,
          outs,    
          games,   // games, maximum number of players
          maxp = 0;


// parallel arrays for players
    int player[TEAMSIZE][3];

    for (int i=0; i < TEAMSIZE; i++)
      for (int j=0; j < 3; j++)
	player[i][j]=0;

// output descriptive messages
    cout << "This program inputs a player's number, and their number " 
	 << "\nof hits, runs and outs for multiple games.\n"
	 << "\n\nEnter the number of games:";

    cin >> games;

    for (int i=0; i < games; i++)
        for (int j=0; j < 9; j++)
  	   {
           // prompt the user for input values
	     cout << "\nEnter the next player's data:";
	     cin >> number >> hits >> walks >> outs;

   	   // update fields
	     player[number][0] += hits;
	     player[number][1] += walks;
	     player[number][2] += outs;
	     if (number > maxp)
	        maxp = number;
	   }

	// display the results
    cout << "\n\nPlayer\tHits\tWalks\tOuts\n"
	 << "------\t----\t-----\t----\n";
    for (int i=0; i <= maxp; i++)
	  cout << endl << i << "\t" << player[i][0] << "\t" 
               << player[i][1] << "\t" << player[i][2];
 	  cout << endl;

} // end of the main
