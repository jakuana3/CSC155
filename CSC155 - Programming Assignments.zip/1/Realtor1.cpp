/************************************************************************
* Name: Your name                                                 CSC 155
* Date: Today's date                                              Lab 1   
*************************************************************************
* Statement: Determine owner, selling cost and commission for house sale
* Specifications:
* Input  - file Realtor1.inp containing
*        - owner
*        - selling cost
* Output - file Realtor1.out containing
*        - owner
*        - selling cost
*        - commission
************************************************************************/

// header files for I/O and string objects
#include <fstream>
#include <iostream>
#include <string>
using namespace std;

// declaration of main program
int main()
{

// objects used to store data
	string seller;  // seller's name
	double price,   // price of the house
	    cost,       // the cost to sell the home
	    commission; // commision on the sale of the listing and selling agents

        ifstream fin("Realtor1.inp");
	ofstream fout("Realtor1.out");

	// output descriptive messages
	cout << "This program calculates the cost to sell a home\n" 
             << "and the commission paid to an individual sales agent.\n\n";

	cout << "The user is asked for the last name of the seller and the\n" 
             << "sales price.\n\n";

        // input values
	cout << "Input is read from the file Realtor1.inp\n" 
             << "Output is printed to the file Realtor1.out\n";

        fin >> seller;
        fin >> price;

	// calculate the cost and the commission
	cost = 0.06 * price;
        commission = 0.015 * price;

	// display the results
	fout << "\nThe " << seller << "'s home sold for $" << price << endl;
	fout << "The cost to sell the home was $" << cost << endl;
	fout << "The selling and listing agent earned $" << commission << endl;

} // end of main

