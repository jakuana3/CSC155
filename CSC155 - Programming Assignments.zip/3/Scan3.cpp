/************************************************************************
* Name: Your name                                                 CSC 155
* Date: Today's date                                              Lab 3   
*************************************************************************
* Statement: Echos the contents of an invoice1.txt and sums prices
* Specifications:
* Input  - string containing item#price in invoice1.txt
* Output - Message indicating the item and the cost
*        - The sum of all costs in inoivce1.txt
************************************************************************/

// Header files for I/O and string
#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
using namespace std;

// declaration of main program
int main()
{

// objects used to store data
  ifstream fin("invoice1.txt");
  string item;
  char newLine;
  double cost, total_cost = 0.0;

// 0. display a statement describing the program
  cout << "This program will read each line of invoice1.txt and print a\n"
       << "statement indicating the item and it's cost.  When the file \n"
       << "is exhausted, it will print the sum of all of the costs.\n\n";

// 1. attempt to read the first line of the file
  getline(fin, item, '#');

  cout << "Item" << setw(15) << "Cost" << setw(5) << endl;

// 2. loop over every line of the file
  //while (!fin.eof())
  while(fin)
    {
      // 3. input the cost
      fin >> cost;
      // 4. update the total coast
      total_cost += cost;
      // 5. ignore the remainder of the input line
      //fin.ignore(100, '\n');  or we could just get the new line character instead...see below
      fin.get(newLine);
      // 6. display the data for this line
      cout << setw(13) << left << item << right << '$' << setw(5)
           << fixed << showpoint << setprecision(2)<< cost << endl;
      // 7. attempt to read anther line
      getline(fin, item, '#');
    }

  // 8. display the sum of all costs in the file
      cout << setw(14) << left << "\nTotal cost" << right 
           << '$' << setw(5)
           << fixed << showpoint << setprecision(2)<< total_cost << endl;

} // end of the main
